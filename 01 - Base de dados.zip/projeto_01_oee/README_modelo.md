# OEE de uma fábrica de alimentos

> Projeto do Mês 01 do Comunidados. Dados fictícios, gerados por simulação.
> Apague este bloco e as instruções em itálico quando terminar.

## O problema

*Em três linhas: o que a fábrica queria saber e por que não conseguia responder.*

## Arquitetura

*Cole aqui o diagrama (imagem ou Mermaid): das origens até a Ouro, com as ferramentas que você usou.*

| Camada | O que guarda | Onde fica | Ferramenta |
|---|---|---|---|
| Bronze | | | |
| Prata | | | |
| Quarentena | | | |
| Ouro | | | |

## Como rodar

*Os comandos, do zero até os números. Quem clonar o repositório deve conseguir repetir.*

```bash
# exemplo
pip install -r requirements.txt
python pipeline.py
```

## Decisões e porquês

*Pelo menos cinco. O que você escolheu, o que deixou de lado e por quê.*

1.
2.
3.
4.
5.

## Meus números e os esperados

Nível que fiz: *essencial / intermediário / avançado*

### Volumes

| Base | Bronze (esperado) | Bronze (meu) | Prata (esperado) | Prata (meu) | Quarentena (esperado) | Quarentena (meu) |
|---|---|---|---|---|---|---|
| Ordens | 159 | | 126 | | 9 | |
| Paradas | 269 | | 259 | | 4 | |
| Inspeções | 1.305 | | 1.188 | | 102 | |
| Sensores | 45.961 | | 45.776 | | 42 | |

### OEE do período, todos os dias

| Linha | D (esperado) | P (esperado) | Q (esperado) | OEE (esperado) | OEE (meu) |
|---|---|---|---|---|---|
| L1 | 93,1% | 85,1% | 97,6% | 77,2% | |
| L2 | 92,7% | 78,0% | 98,1% | 70,9% | |
| L3 | 87,7% | 91,1% | 98,2% | 78,5% | |
| L4 | 88,5% | 91,8% | 98,5% | 80,1% | |
| Fábrica | 90,5% | 86,3% | 98,0% | 76,6% | |

### OEE do período, só dias completos (intermediário)

| Linha | OEE (esperado) | OEE (meu) |
|---|---|---|
| L1 | 85,6% | |
| L2 | 79,7% | |
| L3 | 79,8% | |
| L4 | 83,7% | |
| Fábrica | 82,0% | |

### Outros números

| Indicador | Esperado | Meu |
|---|---|---|
| Maior perda por motivo | Troca de produto (setup), 1.925 min | |
| Paradas programadas | 2.130 min | |
| Sobrepeso total (intermediário) | 9.375,4 kg | |
| Produto que mais reprova (intermediário) | BIS-REC-CHOC-90, 10,5% | |
| Microparadas (avançado) | 1.028 min | |

*Deu diferente? Explique por quê. Entender a diferença vale mais do que acertar de primeira.*

## Respostas para a diretoria

1. **Qual é o OEE de cada linha?**
2. **Quais motivos de parada custam mais tempo?**
3. **Qual produto mais reprova, e quanto damos de sobrepeso?**
4. **Quanto tempo de máquina parada ninguém apontou?**

*Para cada resposta, uma recomendação: o que você diria para a fábrica fazer?*

## O que eu faria diferente em produção

*Volume maior, alerta, custo, segurança, governança.*
